const express = require("express");
const router = express.Router();
const taskController = require("../controller/task.controller");

console.log("📁 task.js 라우터 로딩됨");

router.post("/", taskController.createTask);

router.get("/", taskController.getTask);


// router.get("/", (req, res) => {
//   console.log("✅ GET /api/tasks 도달함");
//   res.send("get tasks");
// });


router.put("/:id", (req, res) => {
  res.send("update task");
});

router.delete("/:id", (req, res) => {
  res.send("delete task");
});


module.exports = router;


